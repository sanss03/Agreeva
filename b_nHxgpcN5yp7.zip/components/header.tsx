"use client"

import { Shield, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

interface HeaderProps {
  children?: React.ReactNode
}

export function Header({ children }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/60 backdrop-blur-xl supports-[backdrop-filter]:bg-background/40">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent blur-lg opacity-60" />
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent shadow-lg">
              <Shield className="h-5 w-5 text-white" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-foreground">
              Samartha<span className="text-primary">Sign</span>
            </span>
            <span className="text-[10px] font-medium text-muted-foreground -mt-1 tracking-wide">
              INCLUSIVE FINANCE
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            How it Works
          </a>
          <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            Features
          </a>
          <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            About
          </a>
        </nav>

        <div className="hidden md:flex items-center gap-3">
          {children}
          <Button variant="ghost" size="sm" className="text-muted-foreground">
            हिंदी
          </Button>
          <Button 
            size="sm" 
            className="bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-lg shadow-primary/25"
          >
            Get Started
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-background/95 backdrop-blur-xl border-b border-border/40 p-4 animate-in slide-in-from-top-2 duration-200">
          <nav className="flex flex-col gap-4">
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors py-2">
              How it Works
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors py-2">
              Features
            </a>
            <a href="#" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors py-2">
              About
            </a>
            <div className="flex items-center gap-3 pt-2">
              <Button variant="ghost" size="sm" className="text-muted-foreground flex-1">
                हिंदी
              </Button>
              <Button 
                size="sm" 
                className="bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity shadow-lg shadow-primary/25 flex-1"
              >
                Get Started
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
